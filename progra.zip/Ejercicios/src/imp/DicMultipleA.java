package imp;

import api.ConjuntoTDA;
import api.DiccionarioMultipleTDA;

public class DicMultipleA implements DiccionarioMultipleTDA {

	class Elemento{
		int clave;
		int cantValores;
		int[] valores;
	}
	
	Elemento[] elementos;
	int cantClaves;
	
	@Override
	public void InicializarDiccionario() {
		elementos = new Elemento[10];
		cantClaves = 0;
	}

	@Override
	public void Agregar(int clave, int valor) {
		int posC = Clave2Indice(clave);
		if (posC == -1) {
			posC = cantClaves;
			elementos[posC]= new Elemento();
			elementos[posC].clave = clave;
			elementos[posC].cantValores = 0;
			elementos[posC].valores = new int[10];
			cantClaves++;
		}
		int posV = Valor2Indice(elementos[posC], valor);
		if (posV == -1) {
			elementos[posC].valores[elementos[posC].cantValores] = valor;
			elementos[posC].cantValores++;
		}
	}

	@Override
	public void Eliminar(int clave) {
		int posC = Clave2Indice(clave);
		if (posC != -1) {
			elementos[posC] = elementos[cantClaves - 1];
			cantClaves--;
		}
	}

	@Override
	public void EliminarValor(int clave, int valor) {
		int posC = Clave2Indice(clave);
		if (posC != -1) {
			int posV = Valor2Indice(elementos[posC], valor);
			if (posV != -1) {
				elementos[posC].valores[posV] = elementos[posC].valores[elementos[posC].cantValores - 1];
				elementos[posC].cantValores--;
				if (elementos[posC].cantValores == 0) {
					Eliminar(clave);
				}
			}
		}
	}

	@Override
	public ConjuntoTDA Recuperar(int clave) {
		ConjuntoTDA c = new ConjuntoTA();
		c.InicializarConjunto ();
		int pos = Clave2Indice(clave);
		if (pos != -1) {
			for (int i = 0; i < elementos[pos].cantValores; i++) {
				c.Agregar(elementos[pos].valores[i]);
			}
		}
		return c;
	}

	@Override
	public ConjuntoTDA Claves() {
		ConjuntoTDA c = new ConjuntoTA();
		c.InicializarConjunto ();
		for (int i = 0; i < cantClaves; i++) {
			c.Agregar(elementos[i].clave);
		}
		return c;
	}

	private int Clave2Indice(int clave){
		int i = cantClaves - 1;
		while(i >= 0 && elementos[i].clave != clave)
			i--;
		return i;
		}
	
	private int Valor2Indice(Elemento e, int valor) {
		int i = e.cantValores - 1;
		while(i >= 0 && e.valores[i] != valor)
			i--;
		return i;
		}
}
