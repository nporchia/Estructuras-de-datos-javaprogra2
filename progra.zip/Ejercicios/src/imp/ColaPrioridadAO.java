package imp;

public class ColaPrioridadAO {

}
