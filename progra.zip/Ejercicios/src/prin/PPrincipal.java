package prin;
import api.PilaTDA;
import imp.Pila;


public class PPrincipal {

	public static void main(String[] args) {
		PilaTDA stack = new Pila();
		stack.InicializarPila();
		stack.Apilar(1);
		stack.Apilar(2);
		stack.Apilar(3);
		mostrarPila(stack);
		stack.Apilar(5);
		stack.Apilar(1);
		stack.Apilar(2);
		stack.Apilar(3);
		mostrarPila(stack);
		stack.Apilar(1);
		stack.Apilar(2);
		stack.Apilar(3);
		stack.Apilar(1);
		stack.Apilar(2);
		stack.Apilar(3);
		System.out.println("-------------------------------------------");
		PilaTDA a = inversopila(stack);
		mostrarPila(a);
		SumarPila(stack);
		contarpila(stack);
		PromedioPila(stack);
		
	}
	
	public static void mostrarPila(PilaTDA X) {
		PilaTDA copia = copiarPila(X);
		while(!copia.PilaVacia()) {
			System.out.print(copia.Tope()+ " ");
			copia.Desapilar();
		}
		System.out.println("");
	}
	
	public static PilaTDA copiarPila(PilaTDA origen) {
		PilaTDA destino = new Pila();
		PilaTDA aux = new Pila();
		destino.InicializarPila();
		aux.InicializarPila();
		while(!origen.PilaVacia()) {
			aux.Apilar(origen.Tope());
			origen.Desapilar();
		}
		while(!aux.PilaVacia()) {
			origen.Apilar(aux.Tope());
			destino.Apilar(aux.Tope());
			aux.Desapilar();
		}
		return destino;
	}


	public static PilaTDA inversopila(PilaTDA origen) {
		PilaTDA copia = copiarPila(origen);
		PilaTDA destino = new Pila();
		destino.InicializarPila();
		while(!copia.PilaVacia()) {
			destino.Apilar(copia.Tope());
			copia.Desapilar();
		}
		return destino;	
	}
	public static void contarpila(PilaTDA origen) {
		PilaTDA copia = copiarPila(origen);
		int a;
		a=0;
		while(!copia.PilaVacia()) {
			a++;
			copia.Desapilar();
		}
		System.out.println("La pila tiene "+ a +" Elementos");	
	}
	public static void SumarPila(PilaTDA origen) {
		PilaTDA copia = copiarPila(origen);
		int a;
		a=0;
		while(!copia.PilaVacia()) {
			a=a+origen.Tope();
			copia.Desapilar();
		}
		System.out.println("La pila suma "+ a);	
	}
	public static void PromedioPila(PilaTDA origen) {
		PilaTDA copia = copiarPila(origen);
		int a,contador;
		contador=0;
		a=0;
		while(!copia.PilaVacia()) {
			a=a+origen.Tope();
			contador++;
			copia.Desapilar();
		}
		System.out.println("El valor promedio de la pila es "+ (a/contador));	
	}
}
	
