package prin;
import api.ColaTDA;
import api.PilaTDA;
import imp.ColaPU;
import imp.Pila;

public class PPrincipalCola {

	static ColaTDA copiarCola(ColaTDA original) {
		ColaTDA aux = new ColaPU();
		ColaTDA copia = new ColaPU();
		aux.InicializarCola();
		copia.InicializarCola();
		while(!original.ColaVacia()) {
			aux.Acolar(original.Primero());
			original.Desacolar();
		}
		while(!aux.ColaVacia()) {
			original.Acolar(aux.Primero());
			copia.Acolar(aux.Primero());
			aux.Desacolar();
		}
		return copia;
	}
	
	static void mostrarCola(ColaTDA X) {
		ColaTDA copia = copiarCola(X);
		System.out.print("[");
		while(!copia.ColaVacia()) {
			System.out.print(copia.Primero());
			copia.Desacolar();
			if (!copia.ColaVacia())
				System.out.print(", ");
		}
		System.out.println("]");
	}
	static ColaTDA pasarCola(ColaTDA X) {
		ColaTDA copia = copiarCola(X);
		ColaTDA destino = new ColaPU();
		destino.InicializarCola();
		while(!copia.ColaVacia()) {
			destino.Acolar(copia.Primero());
			copia.Desacolar();
		}
		return destino;
	}
	static ColaTDA invertirCola(ColaTDA X) {
		ColaTDA copia = copiarCola(X);
		PilaTDA pila = new Pila();
		pila.InicializarPila();
		ColaTDA destino = new ColaPU();
		destino.InicializarCola();
		while (!copia.ColaVacia()) {
			pila.Apilar(copia.Primero());
			copia.Desacolar();
			
		}
		while(!pila.PilaVacia()) {
			destino.Acolar(pila.Tope());
			pila.Desapilar();
		}
		return destino;
	}
	
	public static void main(String[] args) {
		ColaTDA C = new ColaPU();
		C.InicializarCola();
		
		mostrarCola(C);
		C.Acolar(8);
		C.Acolar(11);
		C.Acolar(-2);
		C.Acolar(-2);
		mostrarCola(C);
		C.Acolar(8);
		C.Acolar(17);
		mostrarCola(C);
		ColaTDA a = new ColaPU();
		a=invertirCola(C);
		mostrarCola(a);
		
	}

}
