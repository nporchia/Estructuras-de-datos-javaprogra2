package prin;
import api.ConjuntoTDA;
import imp.ConjuntoTA;
public class prinConju {

	static ConjuntoTDA copiarConjunto(ConjuntoTDA original) {
		ConjuntoTDA aux = new ConjuntoTA();
		ConjuntoTDA copia = new ConjuntoTA();
		aux.InicializarConjunto();
		copia.InicializarConjunto();
		while(!original.ConjuntoVacio()) {
			int x = original.Elegir();
			aux.Agregar(x);
			original.Sacar(x);
		}
		while(!aux.ConjuntoVacio()) {
			int x = aux.Elegir();
			original.Agregar(x);
			copia.Agregar(x);
			aux.Sacar(x);
		}
		return copia;
		
	}
	
	static void mostrarConjunto(ConjuntoTDA a) {
		ConjuntoTDA copia = copiarConjunto(a);
		System.out.print("{");
		while(!copia.ConjuntoVacio()) {
			int x = copia.Elegir();
			System.out.print(x);
			copia.Sacar(x);
			if(!copia.ConjuntoVacio())
				System.out.print(", ");
		}
		System.out.println("}");
	}
	
	public static void main(String[] args) {
		ConjuntoTDA Menge = new ConjuntoTA();
		Menge.InicializarConjunto();
		Menge.Agregar(1);
		Menge.Agregar(3);
		Menge.Agregar(5);
		mostrarConjunto(Menge);
		Menge.Sacar(1);
		Menge.Sacar(2);
		mostrarConjunto(Menge);
		Menge.Sacar(3);
		Menge.Sacar(5);
		mostrarConjunto(Menge);
	}
}
