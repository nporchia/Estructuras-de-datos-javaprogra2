package api;

public interface DiccionarioMultipleTDA {
	void InicializarDiccionario();				// sin precondiciones
	void Agregar(int clave, int valor);			// dic. inicializado
	void Eliminar(int clave);					// dic. inicializado
	void EliminarValor(int clave, int valor);	// dic. inicializado
	ConjuntoTDA Recuperar(int clave);			// dic. inicializado
	ConjuntoTDA Claves();						// dic. inicializado
}