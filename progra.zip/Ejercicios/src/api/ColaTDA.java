package api;

public interface ColaTDA {
	void InicializarCola();		// Sin precondiciones
	void Acolar(int x);			// Cola inicializada
	void Desacolar();			// Cola inicializada y no vac�a
	int Primero();				// Cola inicializada y no vac�a
	boolean ColaVacia();		// Cola inicializada
}
