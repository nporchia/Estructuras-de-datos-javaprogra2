package api;

public interface ColaPrioridadTDA {

}
